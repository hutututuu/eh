const contacts = [
  {
    id: 1,
    name: "Elon Musk",
    img: "https://picsum.photos/seed/ff2233/200",
    email: "elon.musk@volny.cz",
    tel: "+420 777 123 456"
  },
  {
    id: 2,
    name: "Bill Gates",
    img: "https://picsum.photos/seed/ff2s3a/200",
    email: "bill.gates@atlas.cz",
    tel: "+420 602 123 000"
  },
  {
    id: 3,
    name: "Mark Zucker",
    img: "https://picsum.photos/seed/abcdefgh3/200",
    email: "marek@centrum.cz",
    tel: "+420 720 000 000"
  }
];

export default contacts;
